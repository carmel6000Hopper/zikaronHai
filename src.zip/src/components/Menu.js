import React, { Component } from 'react';
import { sidebarOpenStyle, mainStyleOpen, mainStyleClose, sidebarCloseStyle, sidebarClosebtnStyle, openbtnStyle } from './MenuStyle'
export class Menu extends Component {
    constructor(props) {
        super(props);
        this.state = {
            styleButn: sidebarClosebtnStyle ,
            styleSideBar:sidebarCloseStyle ,
            mainStyle: mainStyleClose 
        }
        this.openSideBar = this.openSideBar.bind(this);
        this.closeSideBar = this.closeSideBar.bind(this);
    }
    openSideBar() {

        this.setState({ styleSideBar: sidebarOpenStyle, mainStyle: mainStyleOpen })
        console.log("sidebarOpenStyle", sidebarOpenStyle)
        console.log("mainStyle", this.state.mainStyle)
    }
    closeSideBar() {

        this.setState({ styleSideBar: sidebarCloseStyle, mainStyle: mainStyleClose })
        console.log("sidebarClosebtnStyle", sidebarCloseStyle)
        console.log("mainStyle", this.state.mainStyle)
    }

    render() {
        return (
            <div >
                <div style={Object.assign({}, this.state.styleSideBar, this.state.mainStyle)}>
                    <a href="javascript:void(0)" style={Object.assign({}, this.state.styleSideBar, sidebarClosebtnStyle, this.state.mainStyle)}  onClick={this.closeSideBar}>×</a>
                    <a style = {Object.assign({}, this.state.styleSideBar, this.state.mainStyle)} href="#" ></a>
                    <a style={Object.assign({}, this.state.styleSideBar, this.state.mainStyle)} href="#" >Location</a>
                </div>
                <button style= {openbtnStyle} onClick={this.openSideBar} >☰MENU </button>
            </div>
        )
    }
}

// import 'react-push-menu/styles/component.css';
// import PushMenu from 'react-push-menu';

// export class Menu extends Component {
//     render() {
//         return (
//             <PushMenu
//                 nodes={this.state.menu}
//                 type={'cover'}
//                 propMap={{ url: 'link' }}>

//                 <div className="rpm-trigger" id="rpm-trigger">trigger</div>

//             </PushMenu>
//         );
//     }
// }