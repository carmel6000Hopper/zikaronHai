import React, { Component } from 'react';
import './App.css';
import {Main} from './Main.js'

//import {GoogleMapsContainer} from './components/NameLocation.js'
class App extends Component{
    render(){
       return <Main/>
       //return <GoogleMapsContainer />
    }
}
export default App;