import React from 'react';

const PasswordChangePage = () =>
  <div>
    <h1>Password Change Page</h1>
  </div>

export default PasswordChangePage;