
export const style = {
    height: '80vh',
    display: 'flex',
    marginBottom: 1,
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center'
  };
 export const styleCount = {
    fontSize: '10px',
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center'

  }